package com.rquest.riskmaster.entity;

import java.util.Date;

public class TxnsAccont {
    private String idPartment;

    private String idAccount;

    private String cdTradeType;

    private Date dtSettle;

    private String inOutType;

    private String debitCredit;

    private String cdAccounting;

    private String amtFace;

    private String codeBatch;

    private String idCounterParty;

    private String descriptionAccounting;

    private String cdBundle;

    private String note;

    public String getIdPartment() {
        return idPartment;
    }

    public void setIdPartment(String idPartment) {
        this.idPartment = idPartment == null ? null : idPartment.trim();
    }

    public String getIdAccount() {
        return idAccount;
    }

    public void setIdAccount(String idAccount) {
        this.idAccount = idAccount == null ? null : idAccount.trim();
    }

    public String getCdTradeType() {
        return cdTradeType;
    }

    public void setCdTradeType(String cdTradeType) {
        this.cdTradeType = cdTradeType == null ? null : cdTradeType.trim();
    }

    public Date getDtSettle() {
        return dtSettle;
    }

    public void setDtSettle(Date dtSettle) {
        this.dtSettle = dtSettle;
    }

    public String getInOutType() {
        return inOutType;
    }

    public void setInOutType(String inOutType) {
        this.inOutType = inOutType == null ? null : inOutType.trim();
    }

    public String getDebitCredit() {
        return debitCredit;
    }

    public void setDebitCredit(String debitCredit) {
        this.debitCredit = debitCredit == null ? null : debitCredit.trim();
    }

    public String getCdAccounting() {
        return cdAccounting;
    }

    public void setCdAccounting(String cdAccounting) {
        this.cdAccounting = cdAccounting == null ? null : cdAccounting.trim();
    }

    public String getAmtFace() {
        return amtFace;
    }

    public void setAmtFace(String amtFace) {
        this.amtFace = amtFace == null ? null : amtFace.trim();
    }

    public String getCodeBatch() {
        return codeBatch;
    }

    public void setCodeBatch(String codeBatch) {
        this.codeBatch = codeBatch == null ? null : codeBatch.trim();
    }

    public String getIdCounterParty() {
        return idCounterParty;
    }

    public void setIdCounterParty(String idCounterParty) {
        this.idCounterParty = idCounterParty == null ? null : idCounterParty.trim();
    }

    public String getDescriptionAccounting() {
        return descriptionAccounting;
    }

    public void setDescriptionAccounting(String descriptionAccounting) {
        this.descriptionAccounting = descriptionAccounting == null ? null : descriptionAccounting.trim();
    }

    public String getCdBundle() {
        return cdBundle;
    }

    public void setCdBundle(String cdBundle) {
        this.cdBundle = cdBundle == null ? null : cdBundle.trim();
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }
}
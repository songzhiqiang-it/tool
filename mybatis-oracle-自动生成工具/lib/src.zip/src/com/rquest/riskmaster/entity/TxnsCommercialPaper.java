package com.rquest.riskmaster.entity;

public class TxnsCommercialPaper {
    private String idTrade;

    private String idAgency;

    private String buybizType;

    private String centralBankFlag;

    private String buyType;

    private String cdResellType;

    private String nbrBusiness;

    private String draftType;

    private String draftAttr;

    private String customerType;

    private String dtBuyBackBegin;

    private String dtBuyBackEnd;

    private String idCustomer;

    private String nameCustomer;

    private String dtResell;

    private String dtRepurchase;

    private Double resellRate;

    private String resellRateType;

    private Double buyBackRate;

    private String interestCalculateType;

    private String virtualSellFlag;

    private String innerFlag;

    private String twoWayFlag;

    private String dtTwoWay;

    private String idOperator;

    private String idManager;

    private String idDepartment;

    private String accountStatus;

    private String auditStatus;

    private String maturityStatus;

    private String calcStatus;

    private String inArea;

    private Double rate;

    private String rateType;

    private String dtBuy;

    private String dtBuySellMaturity;

    private String acceptContractNbr;

    private String idWebbankContract;

    private String taskType;

    private Double amtApplyAccept;

    private String dtApplyRemit;

    private String dtMaturity;

    private String appayReason;

    private String firstRepaymentAccount;

    private String secondRepaymentAccount;

    private Double amtTrade;

    private String idDraweeBank;

    private String contractStatus;

    private String logicCheckStatus;

    private String creditCheckStatus;

    private Double nbrVersion;

    public String getIdTrade() {
        return idTrade;
    }

    public void setIdTrade(String idTrade) {
        this.idTrade = idTrade == null ? null : idTrade.trim();
    }

    public String getIdAgency() {
        return idAgency;
    }

    public void setIdAgency(String idAgency) {
        this.idAgency = idAgency == null ? null : idAgency.trim();
    }

    public String getBuybizType() {
        return buybizType;
    }

    public void setBuybizType(String buybizType) {
        this.buybizType = buybizType == null ? null : buybizType.trim();
    }

    public String getCentralBankFlag() {
        return centralBankFlag;
    }

    public void setCentralBankFlag(String centralBankFlag) {
        this.centralBankFlag = centralBankFlag == null ? null : centralBankFlag.trim();
    }

    public String getBuyType() {
        return buyType;
    }

    public void setBuyType(String buyType) {
        this.buyType = buyType == null ? null : buyType.trim();
    }

    public String getCdResellType() {
        return cdResellType;
    }

    public void setCdResellType(String cdResellType) {
        this.cdResellType = cdResellType == null ? null : cdResellType.trim();
    }

    public String getNbrBusiness() {
        return nbrBusiness;
    }

    public void setNbrBusiness(String nbrBusiness) {
        this.nbrBusiness = nbrBusiness == null ? null : nbrBusiness.trim();
    }

    public String getDraftType() {
        return draftType;
    }

    public void setDraftType(String draftType) {
        this.draftType = draftType == null ? null : draftType.trim();
    }

    public String getDraftAttr() {
        return draftAttr;
    }

    public void setDraftAttr(String draftAttr) {
        this.draftAttr = draftAttr == null ? null : draftAttr.trim();
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType == null ? null : customerType.trim();
    }

    public String getDtBuyBackBegin() {
        return dtBuyBackBegin;
    }

    public void setDtBuyBackBegin(String dtBuyBackBegin) {
        this.dtBuyBackBegin = dtBuyBackBegin == null ? null : dtBuyBackBegin.trim();
    }

    public String getDtBuyBackEnd() {
        return dtBuyBackEnd;
    }

    public void setDtBuyBackEnd(String dtBuyBackEnd) {
        this.dtBuyBackEnd = dtBuyBackEnd == null ? null : dtBuyBackEnd.trim();
    }

    public String getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(String idCustomer) {
        this.idCustomer = idCustomer == null ? null : idCustomer.trim();
    }

    public String getNameCustomer() {
        return nameCustomer;
    }

    public void setNameCustomer(String nameCustomer) {
        this.nameCustomer = nameCustomer == null ? null : nameCustomer.trim();
    }

    public String getDtResell() {
        return dtResell;
    }

    public void setDtResell(String dtResell) {
        this.dtResell = dtResell == null ? null : dtResell.trim();
    }

    public String getDtRepurchase() {
        return dtRepurchase;
    }

    public void setDtRepurchase(String dtRepurchase) {
        this.dtRepurchase = dtRepurchase == null ? null : dtRepurchase.trim();
    }

    public Double getResellRate() {
        return resellRate;
    }

    public void setResellRate(Double resellRate) {
        this.resellRate = resellRate;
    }

    public String getResellRateType() {
        return resellRateType;
    }

    public void setResellRateType(String resellRateType) {
        this.resellRateType = resellRateType == null ? null : resellRateType.trim();
    }

    public Double getBuyBackRate() {
        return buyBackRate;
    }

    public void setBuyBackRate(Double buyBackRate) {
        this.buyBackRate = buyBackRate;
    }

    public String getInterestCalculateType() {
        return interestCalculateType;
    }

    public void setInterestCalculateType(String interestCalculateType) {
        this.interestCalculateType = interestCalculateType == null ? null : interestCalculateType.trim();
    }

    public String getVirtualSellFlag() {
        return virtualSellFlag;
    }

    public void setVirtualSellFlag(String virtualSellFlag) {
        this.virtualSellFlag = virtualSellFlag == null ? null : virtualSellFlag.trim();
    }

    public String getInnerFlag() {
        return innerFlag;
    }

    public void setInnerFlag(String innerFlag) {
        this.innerFlag = innerFlag == null ? null : innerFlag.trim();
    }

    public String getTwoWayFlag() {
        return twoWayFlag;
    }

    public void setTwoWayFlag(String twoWayFlag) {
        this.twoWayFlag = twoWayFlag == null ? null : twoWayFlag.trim();
    }

    public String getDtTwoWay() {
        return dtTwoWay;
    }

    public void setDtTwoWay(String dtTwoWay) {
        this.dtTwoWay = dtTwoWay == null ? null : dtTwoWay.trim();
    }

    public String getIdOperator() {
        return idOperator;
    }

    public void setIdOperator(String idOperator) {
        this.idOperator = idOperator == null ? null : idOperator.trim();
    }

    public String getIdManager() {
        return idManager;
    }

    public void setIdManager(String idManager) {
        this.idManager = idManager == null ? null : idManager.trim();
    }

    public String getIdDepartment() {
        return idDepartment;
    }

    public void setIdDepartment(String idDepartment) {
        this.idDepartment = idDepartment == null ? null : idDepartment.trim();
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus == null ? null : accountStatus.trim();
    }

    public String getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(String auditStatus) {
        this.auditStatus = auditStatus == null ? null : auditStatus.trim();
    }

    public String getMaturityStatus() {
        return maturityStatus;
    }

    public void setMaturityStatus(String maturityStatus) {
        this.maturityStatus = maturityStatus == null ? null : maturityStatus.trim();
    }

    public String getCalcStatus() {
        return calcStatus;
    }

    public void setCalcStatus(String calcStatus) {
        this.calcStatus = calcStatus == null ? null : calcStatus.trim();
    }

    public String getInArea() {
        return inArea;
    }

    public void setInArea(String inArea) {
        this.inArea = inArea == null ? null : inArea.trim();
    }

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    public String getRateType() {
        return rateType;
    }

    public void setRateType(String rateType) {
        this.rateType = rateType == null ? null : rateType.trim();
    }

    public String getDtBuy() {
        return dtBuy;
    }

    public void setDtBuy(String dtBuy) {
        this.dtBuy = dtBuy == null ? null : dtBuy.trim();
    }

    public String getDtBuySellMaturity() {
        return dtBuySellMaturity;
    }

    public void setDtBuySellMaturity(String dtBuySellMaturity) {
        this.dtBuySellMaturity = dtBuySellMaturity == null ? null : dtBuySellMaturity.trim();
    }

    public String getAcceptContractNbr() {
        return acceptContractNbr;
    }

    public void setAcceptContractNbr(String acceptContractNbr) {
        this.acceptContractNbr = acceptContractNbr == null ? null : acceptContractNbr.trim();
    }

    public String getIdWebbankContract() {
        return idWebbankContract;
    }

    public void setIdWebbankContract(String idWebbankContract) {
        this.idWebbankContract = idWebbankContract == null ? null : idWebbankContract.trim();
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }

    public Double getAmtApplyAccept() {
        return amtApplyAccept;
    }

    public void setAmtApplyAccept(Double amtApplyAccept) {
        this.amtApplyAccept = amtApplyAccept;
    }

    public String getDtApplyRemit() {
        return dtApplyRemit;
    }

    public void setDtApplyRemit(String dtApplyRemit) {
        this.dtApplyRemit = dtApplyRemit == null ? null : dtApplyRemit.trim();
    }

    public String getDtMaturity() {
        return dtMaturity;
    }

    public void setDtMaturity(String dtMaturity) {
        this.dtMaturity = dtMaturity == null ? null : dtMaturity.trim();
    }

    public String getAppayReason() {
        return appayReason;
    }

    public void setAppayReason(String appayReason) {
        this.appayReason = appayReason == null ? null : appayReason.trim();
    }

    public String getFirstRepaymentAccount() {
        return firstRepaymentAccount;
    }

    public void setFirstRepaymentAccount(String firstRepaymentAccount) {
        this.firstRepaymentAccount = firstRepaymentAccount == null ? null : firstRepaymentAccount.trim();
    }

    public String getSecondRepaymentAccount() {
        return secondRepaymentAccount;
    }

    public void setSecondRepaymentAccount(String secondRepaymentAccount) {
        this.secondRepaymentAccount = secondRepaymentAccount == null ? null : secondRepaymentAccount.trim();
    }

    public Double getAmtTrade() {
        return amtTrade;
    }

    public void setAmtTrade(Double amtTrade) {
        this.amtTrade = amtTrade;
    }

    public String getIdDraweeBank() {
        return idDraweeBank;
    }

    public void setIdDraweeBank(String idDraweeBank) {
        this.idDraweeBank = idDraweeBank == null ? null : idDraweeBank.trim();
    }

    public String getContractStatus() {
        return contractStatus;
    }

    public void setContractStatus(String contractStatus) {
        this.contractStatus = contractStatus == null ? null : contractStatus.trim();
    }

    public String getLogicCheckStatus() {
        return logicCheckStatus;
    }

    public void setLogicCheckStatus(String logicCheckStatus) {
        this.logicCheckStatus = logicCheckStatus == null ? null : logicCheckStatus.trim();
    }

    public String getCreditCheckStatus() {
        return creditCheckStatus;
    }

    public void setCreditCheckStatus(String creditCheckStatus) {
        this.creditCheckStatus = creditCheckStatus == null ? null : creditCheckStatus.trim();
    }

    public Double getNbrVersion() {
        return nbrVersion;
    }

    public void setNbrVersion(Double nbrVersion) {
        this.nbrVersion = nbrVersion;
    }
}
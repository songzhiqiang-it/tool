package com.rquest.riskmaster.entity;

import java.util.Date;

public class TxnsCommercialPaperBalance {
    private String idDraft;

    private String draftNumber;

    private String idBuyContract;

    private String draftAttr;

    private String draftType;

    private Double amtFace;

    private String idBelongBranch;

    private String storeStatus;

    private String status;

    private String tmpStatus;

    private Date dtBatch;

    private String businessType;

    private Double nbrVersion;

    public String getIdDraft() {
        return idDraft;
    }

    public void setIdDraft(String idDraft) {
        this.idDraft = idDraft == null ? null : idDraft.trim();
    }

    public String getDraftNumber() {
        return draftNumber;
    }

    public void setDraftNumber(String draftNumber) {
        this.draftNumber = draftNumber == null ? null : draftNumber.trim();
    }

    public String getIdBuyContract() {
        return idBuyContract;
    }

    public void setIdBuyContract(String idBuyContract) {
        this.idBuyContract = idBuyContract == null ? null : idBuyContract.trim();
    }

    public String getDraftAttr() {
        return draftAttr;
    }

    public void setDraftAttr(String draftAttr) {
        this.draftAttr = draftAttr == null ? null : draftAttr.trim();
    }

    public String getDraftType() {
        return draftType;
    }

    public void setDraftType(String draftType) {
        this.draftType = draftType == null ? null : draftType.trim();
    }

    public Double getAmtFace() {
        return amtFace;
    }

    public void setAmtFace(Double amtFace) {
        this.amtFace = amtFace;
    }

    public String getIdBelongBranch() {
        return idBelongBranch;
    }

    public void setIdBelongBranch(String idBelongBranch) {
        this.idBelongBranch = idBelongBranch == null ? null : idBelongBranch.trim();
    }

    public String getStoreStatus() {
        return storeStatus;
    }

    public void setStoreStatus(String storeStatus) {
        this.storeStatus = storeStatus == null ? null : storeStatus.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getTmpStatus() {
        return tmpStatus;
    }

    public void setTmpStatus(String tmpStatus) {
        this.tmpStatus = tmpStatus == null ? null : tmpStatus.trim();
    }

    public Date getDtBatch() {
        return dtBatch;
    }

    public void setDtBatch(Date dtBatch) {
        this.dtBatch = dtBatch;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType == null ? null : businessType.trim();
    }

    public Double getNbrVersion() {
        return nbrVersion;
    }

    public void setNbrVersion(Double nbrVersion) {
        this.nbrVersion = nbrVersion;
    }
}
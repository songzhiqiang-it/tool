package com.rquest.riskmaster.entity;

import java.util.Date;

public class TxnsAssetBalance {
    private String idBaretrade;

    private String idBalance;

    private String idAlterBalance;

    private String idPartment;

    private String idAccount;

    private Date dtSettle;

    private String cdAssetTyppe;

    private String cdBusinessType;

    private String cdMajorAsset;

    private String cdMinorAsset;

    private Double amtHoldPositon;

    private Double amtHoldFace;

    private Double amtCleanPriceCose;

    private Double interestAdjust;

    private Double fairValueAlter;

    private Double amtInterestCost;

    private Double amtDirtyPriceCose;

    private Double amtPriceEarning;

    private Double amtAmortizeEarning;

    private Double amtInterestEarning;

    private Double fairValueIncome;

    private Double amtTradeExpense;

    private Double rateReal;

    private Date dtEffective;

    private Date dtMaturity;

    private Double amtIncurred;

    public String getIdBaretrade() {
        return idBaretrade;
    }

    public void setIdBaretrade(String idBaretrade) {
        this.idBaretrade = idBaretrade == null ? null : idBaretrade.trim();
    }

    public String getIdBalance() {
        return idBalance;
    }

    public void setIdBalance(String idBalance) {
        this.idBalance = idBalance == null ? null : idBalance.trim();
    }

    public String getIdAlterBalance() {
        return idAlterBalance;
    }

    public void setIdAlterBalance(String idAlterBalance) {
        this.idAlterBalance = idAlterBalance == null ? null : idAlterBalance.trim();
    }

    public String getIdPartment() {
        return idPartment;
    }

    public void setIdPartment(String idPartment) {
        this.idPartment = idPartment == null ? null : idPartment.trim();
    }

    public String getIdAccount() {
        return idAccount;
    }

    public void setIdAccount(String idAccount) {
        this.idAccount = idAccount == null ? null : idAccount.trim();
    }

    public Date getDtSettle() {
        return dtSettle;
    }

    public void setDtSettle(Date dtSettle) {
        this.dtSettle = dtSettle;
    }

    public String getCdAssetTyppe() {
        return cdAssetTyppe;
    }

    public void setCdAssetTyppe(String cdAssetTyppe) {
        this.cdAssetTyppe = cdAssetTyppe == null ? null : cdAssetTyppe.trim();
    }

    public String getCdBusinessType() {
        return cdBusinessType;
    }

    public void setCdBusinessType(String cdBusinessType) {
        this.cdBusinessType = cdBusinessType == null ? null : cdBusinessType.trim();
    }

    public String getCdMajorAsset() {
        return cdMajorAsset;
    }

    public void setCdMajorAsset(String cdMajorAsset) {
        this.cdMajorAsset = cdMajorAsset == null ? null : cdMajorAsset.trim();
    }

    public String getCdMinorAsset() {
        return cdMinorAsset;
    }

    public void setCdMinorAsset(String cdMinorAsset) {
        this.cdMinorAsset = cdMinorAsset == null ? null : cdMinorAsset.trim();
    }

    public Double getAmtHoldPositon() {
        return amtHoldPositon;
    }

    public void setAmtHoldPositon(Double amtHoldPositon) {
        this.amtHoldPositon = amtHoldPositon;
    }

    public Double getAmtHoldFace() {
        return amtHoldFace;
    }

    public void setAmtHoldFace(Double amtHoldFace) {
        this.amtHoldFace = amtHoldFace;
    }

    public Double getAmtCleanPriceCose() {
        return amtCleanPriceCose;
    }

    public void setAmtCleanPriceCose(Double amtCleanPriceCose) {
        this.amtCleanPriceCose = amtCleanPriceCose;
    }

    public Double getInterestAdjust() {
        return interestAdjust;
    }

    public void setInterestAdjust(Double interestAdjust) {
        this.interestAdjust = interestAdjust;
    }

    public Double getFairValueAlter() {
        return fairValueAlter;
    }

    public void setFairValueAlter(Double fairValueAlter) {
        this.fairValueAlter = fairValueAlter;
    }

    public Double getAmtInterestCost() {
        return amtInterestCost;
    }

    public void setAmtInterestCost(Double amtInterestCost) {
        this.amtInterestCost = amtInterestCost;
    }

    public Double getAmtDirtyPriceCose() {
        return amtDirtyPriceCose;
    }

    public void setAmtDirtyPriceCose(Double amtDirtyPriceCose) {
        this.amtDirtyPriceCose = amtDirtyPriceCose;
    }

    public Double getAmtPriceEarning() {
        return amtPriceEarning;
    }

    public void setAmtPriceEarning(Double amtPriceEarning) {
        this.amtPriceEarning = amtPriceEarning;
    }

    public Double getAmtAmortizeEarning() {
        return amtAmortizeEarning;
    }

    public void setAmtAmortizeEarning(Double amtAmortizeEarning) {
        this.amtAmortizeEarning = amtAmortizeEarning;
    }

    public Double getAmtInterestEarning() {
        return amtInterestEarning;
    }

    public void setAmtInterestEarning(Double amtInterestEarning) {
        this.amtInterestEarning = amtInterestEarning;
    }

    public Double getFairValueIncome() {
        return fairValueIncome;
    }

    public void setFairValueIncome(Double fairValueIncome) {
        this.fairValueIncome = fairValueIncome;
    }

    public Double getAmtTradeExpense() {
        return amtTradeExpense;
    }

    public void setAmtTradeExpense(Double amtTradeExpense) {
        this.amtTradeExpense = amtTradeExpense;
    }

    public Double getRateReal() {
        return rateReal;
    }

    public void setRateReal(Double rateReal) {
        this.rateReal = rateReal;
    }

    public Date getDtEffective() {
        return dtEffective;
    }

    public void setDtEffective(Date dtEffective) {
        this.dtEffective = dtEffective;
    }

    public Date getDtMaturity() {
        return dtMaturity;
    }

    public void setDtMaturity(Date dtMaturity) {
        this.dtMaturity = dtMaturity;
    }

    public Double getAmtIncurred() {
        return amtIncurred;
    }

    public void setAmtIncurred(Double amtIncurred) {
        this.amtIncurred = amtIncurred;
    }
}
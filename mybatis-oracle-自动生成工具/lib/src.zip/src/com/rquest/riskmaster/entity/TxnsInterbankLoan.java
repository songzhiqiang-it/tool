package com.rquest.riskmaster.entity;

import java.util.Date;

public class TxnsInterbankLoan {
    private Double idTransaction;

    private String idTrade;

    private String idCounterparty;

    private String cdBusinessDayConvention;

    private String cdDayCountConvention;

    private String cdPayFrequencyPeriod;

    private Date dtEffective;

    private Date dtMaturity;

    private Double nbrLoanDays;

    private Double rateLoan;

    private String idDepartment;

    private Double amtMaturity;

    private Double amtInterest;

    private String nameDealer;

    private Double amtNotional;

    private Date dtTrading;

    private String cdTradeDirection;

    private String idPortfolio;

    private String namePortfolio;

    private String nameCounterparty;

    private Double amtFee;

    private Double amtTax;

    private Double amtBrokage;

    private String idBankAccount;

    private String nameBankAccount;

    private String idAccount;

    private String nameAccount;

    private String accountType;

    private String txtNote;

    private String idAgency;

    private String idCust;

    private String nameCust;

    private String loanType;

    private String cdContract;

    private String idBorrowAccount;

    private String idIou;

    private Double amtAccountBalance;

    private Double amtSettlement;

    private Double amtContract;

    private Double depositPeriod;

    private String flagAnnualOrMonthlyRate;

    private String guaranteeMethod;

    private String idInstrument;

    public Double getIdTransaction() {
        return idTransaction;
    }

    public void setIdTransaction(Double idTransaction) {
        this.idTransaction = idTransaction;
    }

    public String getIdTrade() {
        return idTrade;
    }

    public void setIdTrade(String idTrade) {
        this.idTrade = idTrade == null ? null : idTrade.trim();
    }

    public String getIdCounterparty() {
        return idCounterparty;
    }

    public void setIdCounterparty(String idCounterparty) {
        this.idCounterparty = idCounterparty == null ? null : idCounterparty.trim();
    }

    public String getCdBusinessDayConvention() {
        return cdBusinessDayConvention;
    }

    public void setCdBusinessDayConvention(String cdBusinessDayConvention) {
        this.cdBusinessDayConvention = cdBusinessDayConvention == null ? null : cdBusinessDayConvention.trim();
    }

    public String getCdDayCountConvention() {
        return cdDayCountConvention;
    }

    public void setCdDayCountConvention(String cdDayCountConvention) {
        this.cdDayCountConvention = cdDayCountConvention == null ? null : cdDayCountConvention.trim();
    }

    public String getCdPayFrequencyPeriod() {
        return cdPayFrequencyPeriod;
    }

    public void setCdPayFrequencyPeriod(String cdPayFrequencyPeriod) {
        this.cdPayFrequencyPeriod = cdPayFrequencyPeriod == null ? null : cdPayFrequencyPeriod.trim();
    }

    public Date getDtEffective() {
        return dtEffective;
    }

    public void setDtEffective(Date dtEffective) {
        this.dtEffective = dtEffective;
    }

    public Date getDtMaturity() {
        return dtMaturity;
    }

    public void setDtMaturity(Date dtMaturity) {
        this.dtMaturity = dtMaturity;
    }

    public Double getNbrLoanDays() {
        return nbrLoanDays;
    }

    public void setNbrLoanDays(Double nbrLoanDays) {
        this.nbrLoanDays = nbrLoanDays;
    }

    public Double getRateLoan() {
        return rateLoan;
    }

    public void setRateLoan(Double rateLoan) {
        this.rateLoan = rateLoan;
    }

    public String getIdDepartment() {
        return idDepartment;
    }

    public void setIdDepartment(String idDepartment) {
        this.idDepartment = idDepartment == null ? null : idDepartment.trim();
    }

    public Double getAmtMaturity() {
        return amtMaturity;
    }

    public void setAmtMaturity(Double amtMaturity) {
        this.amtMaturity = amtMaturity;
    }

    public Double getAmtInterest() {
        return amtInterest;
    }

    public void setAmtInterest(Double amtInterest) {
        this.amtInterest = amtInterest;
    }

    public String getNameDealer() {
        return nameDealer;
    }

    public void setNameDealer(String nameDealer) {
        this.nameDealer = nameDealer == null ? null : nameDealer.trim();
    }

    public Double getAmtNotional() {
        return amtNotional;
    }

    public void setAmtNotional(Double amtNotional) {
        this.amtNotional = amtNotional;
    }

    public Date getDtTrading() {
        return dtTrading;
    }

    public void setDtTrading(Date dtTrading) {
        this.dtTrading = dtTrading;
    }

    public String getCdTradeDirection() {
        return cdTradeDirection;
    }

    public void setCdTradeDirection(String cdTradeDirection) {
        this.cdTradeDirection = cdTradeDirection == null ? null : cdTradeDirection.trim();
    }

    public String getIdPortfolio() {
        return idPortfolio;
    }

    public void setIdPortfolio(String idPortfolio) {
        this.idPortfolio = idPortfolio == null ? null : idPortfolio.trim();
    }

    public String getNamePortfolio() {
        return namePortfolio;
    }

    public void setNamePortfolio(String namePortfolio) {
        this.namePortfolio = namePortfolio == null ? null : namePortfolio.trim();
    }

    public String getNameCounterparty() {
        return nameCounterparty;
    }

    public void setNameCounterparty(String nameCounterparty) {
        this.nameCounterparty = nameCounterparty == null ? null : nameCounterparty.trim();
    }

    public Double getAmtFee() {
        return amtFee;
    }

    public void setAmtFee(Double amtFee) {
        this.amtFee = amtFee;
    }

    public Double getAmtTax() {
        return amtTax;
    }

    public void setAmtTax(Double amtTax) {
        this.amtTax = amtTax;
    }

    public Double getAmtBrokage() {
        return amtBrokage;
    }

    public void setAmtBrokage(Double amtBrokage) {
        this.amtBrokage = amtBrokage;
    }

    public String getIdBankAccount() {
        return idBankAccount;
    }

    public void setIdBankAccount(String idBankAccount) {
        this.idBankAccount = idBankAccount == null ? null : idBankAccount.trim();
    }

    public String getNameBankAccount() {
        return nameBankAccount;
    }

    public void setNameBankAccount(String nameBankAccount) {
        this.nameBankAccount = nameBankAccount == null ? null : nameBankAccount.trim();
    }

    public String getIdAccount() {
        return idAccount;
    }

    public void setIdAccount(String idAccount) {
        this.idAccount = idAccount == null ? null : idAccount.trim();
    }

    public String getNameAccount() {
        return nameAccount;
    }

    public void setNameAccount(String nameAccount) {
        this.nameAccount = nameAccount == null ? null : nameAccount.trim();
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType == null ? null : accountType.trim();
    }

    public String getTxtNote() {
        return txtNote;
    }

    public void setTxtNote(String txtNote) {
        this.txtNote = txtNote == null ? null : txtNote.trim();
    }

    public String getIdAgency() {
        return idAgency;
    }

    public void setIdAgency(String idAgency) {
        this.idAgency = idAgency == null ? null : idAgency.trim();
    }

    public String getIdCust() {
        return idCust;
    }

    public void setIdCust(String idCust) {
        this.idCust = idCust == null ? null : idCust.trim();
    }

    public String getNameCust() {
        return nameCust;
    }

    public void setNameCust(String nameCust) {
        this.nameCust = nameCust == null ? null : nameCust.trim();
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType == null ? null : loanType.trim();
    }

    public String getCdContract() {
        return cdContract;
    }

    public void setCdContract(String cdContract) {
        this.cdContract = cdContract == null ? null : cdContract.trim();
    }

    public String getIdBorrowAccount() {
        return idBorrowAccount;
    }

    public void setIdBorrowAccount(String idBorrowAccount) {
        this.idBorrowAccount = idBorrowAccount == null ? null : idBorrowAccount.trim();
    }

    public String getIdIou() {
        return idIou;
    }

    public void setIdIou(String idIou) {
        this.idIou = idIou == null ? null : idIou.trim();
    }

    public Double getAmtAccountBalance() {
        return amtAccountBalance;
    }

    public void setAmtAccountBalance(Double amtAccountBalance) {
        this.amtAccountBalance = amtAccountBalance;
    }

    public Double getAmtSettlement() {
        return amtSettlement;
    }

    public void setAmtSettlement(Double amtSettlement) {
        this.amtSettlement = amtSettlement;
    }

    public Double getAmtContract() {
        return amtContract;
    }

    public void setAmtContract(Double amtContract) {
        this.amtContract = amtContract;
    }

    public Double getDepositPeriod() {
        return depositPeriod;
    }

    public void setDepositPeriod(Double depositPeriod) {
        this.depositPeriod = depositPeriod;
    }

    public String getFlagAnnualOrMonthlyRate() {
        return flagAnnualOrMonthlyRate;
    }

    public void setFlagAnnualOrMonthlyRate(String flagAnnualOrMonthlyRate) {
        this.flagAnnualOrMonthlyRate = flagAnnualOrMonthlyRate == null ? null : flagAnnualOrMonthlyRate.trim();
    }

    public String getGuaranteeMethod() {
        return guaranteeMethod;
    }

    public void setGuaranteeMethod(String guaranteeMethod) {
        this.guaranteeMethod = guaranteeMethod == null ? null : guaranteeMethod.trim();
    }

    public String getIdInstrument() {
        return idInstrument;
    }

    public void setIdInstrument(String idInstrument) {
        this.idInstrument = idInstrument == null ? null : idInstrument.trim();
    }
}
package com.rquest.riskmaster.entity;

import java.util.Date;

public class TxnsWiForClient {
    private String idTransaction;

    private String assetType;

    private String assetSubType;

    private String idTrade;

    private String idProduct;

    private String cdAsset;

    private String nameAsset;

    private Date dtTrade;

    private Date dtEffective;

    private Date dtContractMaturity;

    private String cdTradeDirection;

    private Double amtTotalShare;

    private Double rateAnnual;

    private Double amtInterest;

    private Double amtPaidInterest;

    private Double amtPrice;

    private Double amtNotional;

    private String cdCurrency;

    private String cdDayCountConvention;

    private Double amtFee;

    private Double amtTax;

    private Double amtBrokage;

    private String idDepartment;

    private String nameCounterParty;

    private String idCounterParty;

    private String firstSettleType;

    private Double amtSettle;

    private String idDealer;

    private String nbrSerial;

    private Double nbrHoldDays;

    private Double amtMaturityIncome;

    private String flagMaturity;

    private String flagBondType;

    private Double rateCoupon;

    private Double amtCleanPrice;

    private String cdIntrustType;

    private String cdBondType;

    private String cdType;

    public String getIdTransaction() {
        return idTransaction;
    }

    public void setIdTransaction(String idTransaction) {
        this.idTransaction = idTransaction == null ? null : idTransaction.trim();
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType == null ? null : assetType.trim();
    }

    public String getAssetSubType() {
        return assetSubType;
    }

    public void setAssetSubType(String assetSubType) {
        this.assetSubType = assetSubType == null ? null : assetSubType.trim();
    }

    public String getIdTrade() {
        return idTrade;
    }

    public void setIdTrade(String idTrade) {
        this.idTrade = idTrade == null ? null : idTrade.trim();
    }

    public String getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(String idProduct) {
        this.idProduct = idProduct == null ? null : idProduct.trim();
    }

    public String getCdAsset() {
        return cdAsset;
    }

    public void setCdAsset(String cdAsset) {
        this.cdAsset = cdAsset == null ? null : cdAsset.trim();
    }

    public String getNameAsset() {
        return nameAsset;
    }

    public void setNameAsset(String nameAsset) {
        this.nameAsset = nameAsset == null ? null : nameAsset.trim();
    }

    public Date getDtTrade() {
        return dtTrade;
    }

    public void setDtTrade(Date dtTrade) {
        this.dtTrade = dtTrade;
    }

    public Date getDtEffective() {
        return dtEffective;
    }

    public void setDtEffective(Date dtEffective) {
        this.dtEffective = dtEffective;
    }

    public Date getDtContractMaturity() {
        return dtContractMaturity;
    }

    public void setDtContractMaturity(Date dtContractMaturity) {
        this.dtContractMaturity = dtContractMaturity;
    }

    public String getCdTradeDirection() {
        return cdTradeDirection;
    }

    public void setCdTradeDirection(String cdTradeDirection) {
        this.cdTradeDirection = cdTradeDirection == null ? null : cdTradeDirection.trim();
    }

    public Double getAmtTotalShare() {
        return amtTotalShare;
    }

    public void setAmtTotalShare(Double amtTotalShare) {
        this.amtTotalShare = amtTotalShare;
    }

    public Double getRateAnnual() {
        return rateAnnual;
    }

    public void setRateAnnual(Double rateAnnual) {
        this.rateAnnual = rateAnnual;
    }

    public Double getAmtInterest() {
        return amtInterest;
    }

    public void setAmtInterest(Double amtInterest) {
        this.amtInterest = amtInterest;
    }

    public Double getAmtPaidInterest() {
        return amtPaidInterest;
    }

    public void setAmtPaidInterest(Double amtPaidInterest) {
        this.amtPaidInterest = amtPaidInterest;
    }

    public Double getAmtPrice() {
        return amtPrice;
    }

    public void setAmtPrice(Double amtPrice) {
        this.amtPrice = amtPrice;
    }

    public Double getAmtNotional() {
        return amtNotional;
    }

    public void setAmtNotional(Double amtNotional) {
        this.amtNotional = amtNotional;
    }

    public String getCdCurrency() {
        return cdCurrency;
    }

    public void setCdCurrency(String cdCurrency) {
        this.cdCurrency = cdCurrency == null ? null : cdCurrency.trim();
    }

    public String getCdDayCountConvention() {
        return cdDayCountConvention;
    }

    public void setCdDayCountConvention(String cdDayCountConvention) {
        this.cdDayCountConvention = cdDayCountConvention == null ? null : cdDayCountConvention.trim();
    }

    public Double getAmtFee() {
        return amtFee;
    }

    public void setAmtFee(Double amtFee) {
        this.amtFee = amtFee;
    }

    public Double getAmtTax() {
        return amtTax;
    }

    public void setAmtTax(Double amtTax) {
        this.amtTax = amtTax;
    }

    public Double getAmtBrokage() {
        return amtBrokage;
    }

    public void setAmtBrokage(Double amtBrokage) {
        this.amtBrokage = amtBrokage;
    }

    public String getIdDepartment() {
        return idDepartment;
    }

    public void setIdDepartment(String idDepartment) {
        this.idDepartment = idDepartment == null ? null : idDepartment.trim();
    }

    public String getNameCounterParty() {
        return nameCounterParty;
    }

    public void setNameCounterParty(String nameCounterParty) {
        this.nameCounterParty = nameCounterParty == null ? null : nameCounterParty.trim();
    }

    public String getIdCounterParty() {
        return idCounterParty;
    }

    public void setIdCounterParty(String idCounterParty) {
        this.idCounterParty = idCounterParty == null ? null : idCounterParty.trim();
    }

    public String getFirstSettleType() {
        return firstSettleType;
    }

    public void setFirstSettleType(String firstSettleType) {
        this.firstSettleType = firstSettleType == null ? null : firstSettleType.trim();
    }

    public Double getAmtSettle() {
        return amtSettle;
    }

    public void setAmtSettle(Double amtSettle) {
        this.amtSettle = amtSettle;
    }

    public String getIdDealer() {
        return idDealer;
    }

    public void setIdDealer(String idDealer) {
        this.idDealer = idDealer == null ? null : idDealer.trim();
    }

    public String getNbrSerial() {
        return nbrSerial;
    }

    public void setNbrSerial(String nbrSerial) {
        this.nbrSerial = nbrSerial == null ? null : nbrSerial.trim();
    }

    public Double getNbrHoldDays() {
        return nbrHoldDays;
    }

    public void setNbrHoldDays(Double nbrHoldDays) {
        this.nbrHoldDays = nbrHoldDays;
    }

    public Double getAmtMaturityIncome() {
        return amtMaturityIncome;
    }

    public void setAmtMaturityIncome(Double amtMaturityIncome) {
        this.amtMaturityIncome = amtMaturityIncome;
    }

    public String getFlagMaturity() {
        return flagMaturity;
    }

    public void setFlagMaturity(String flagMaturity) {
        this.flagMaturity = flagMaturity == null ? null : flagMaturity.trim();
    }

    public String getFlagBondType() {
        return flagBondType;
    }

    public void setFlagBondType(String flagBondType) {
        this.flagBondType = flagBondType == null ? null : flagBondType.trim();
    }

    public Double getRateCoupon() {
        return rateCoupon;
    }

    public void setRateCoupon(Double rateCoupon) {
        this.rateCoupon = rateCoupon;
    }

    public Double getAmtCleanPrice() {
        return amtCleanPrice;
    }

    public void setAmtCleanPrice(Double amtCleanPrice) {
        this.amtCleanPrice = amtCleanPrice;
    }

    public String getCdIntrustType() {
        return cdIntrustType;
    }

    public void setCdIntrustType(String cdIntrustType) {
        this.cdIntrustType = cdIntrustType == null ? null : cdIntrustType.trim();
    }

    public String getCdBondType() {
        return cdBondType;
    }

    public void setCdBondType(String cdBondType) {
        this.cdBondType = cdBondType == null ? null : cdBondType.trim();
    }

    public String getCdType() {
        return cdType;
    }

    public void setCdType(String cdType) {
        this.cdType = cdType == null ? null : cdType.trim();
    }
}
package com.rquest.riskmaster.entity;

import java.util.Date;

public class TxnsBond {
    private Double idTransaction;

    private String cdBond;

    private String nameBond;

    private String nbrSerial;

    private String cdBondType;

    private String idPortfolio;

    private String namePortfolio;

    private String idDepartment;

    private String idTrader;

    private String idTrade;

    private String cdAssetClass;

    private String cdAssetSubClass;

    private Date dtTrade;

    private Date dtSettle;

    private String cdSettleType;

    private String cdTradeDirection;

    private String cdEvent;

    private Double amtPriceClean;

    private Double amtPriceFull;

    private Double rateCoupon;

    private Double amtNotional;

    private Double amtAccruedInt;

    private Double amtSettle;

    private Double rateYtm;

    private String nameCounterparty;

    private Double amtPremiumDiscount;

    private String idReviewer;

    private String idConfirmer;

    private Double amtDistributionPrice;

    private Double ratioDistributionFee;

    private Double amtUnderwritingPrice;

    private Double amtFullFee;

    private Double amtFullTax;

    private Double amtFullBrokage;

    private String nameAccount;

    private String txtNote;

    private String idInstrument;

    public Double getIdTransaction() {
        return idTransaction;
    }

    public void setIdTransaction(Double idTransaction) {
        this.idTransaction = idTransaction;
    }

    public String getCdBond() {
        return cdBond;
    }

    public void setCdBond(String cdBond) {
        this.cdBond = cdBond == null ? null : cdBond.trim();
    }

    public String getNameBond() {
        return nameBond;
    }

    public void setNameBond(String nameBond) {
        this.nameBond = nameBond == null ? null : nameBond.trim();
    }

    public String getNbrSerial() {
        return nbrSerial;
    }

    public void setNbrSerial(String nbrSerial) {
        this.nbrSerial = nbrSerial == null ? null : nbrSerial.trim();
    }

    public String getCdBondType() {
        return cdBondType;
    }

    public void setCdBondType(String cdBondType) {
        this.cdBondType = cdBondType == null ? null : cdBondType.trim();
    }

    public String getIdPortfolio() {
        return idPortfolio;
    }

    public void setIdPortfolio(String idPortfolio) {
        this.idPortfolio = idPortfolio == null ? null : idPortfolio.trim();
    }

    public String getNamePortfolio() {
        return namePortfolio;
    }

    public void setNamePortfolio(String namePortfolio) {
        this.namePortfolio = namePortfolio == null ? null : namePortfolio.trim();
    }

    public String getIdDepartment() {
        return idDepartment;
    }

    public void setIdDepartment(String idDepartment) {
        this.idDepartment = idDepartment == null ? null : idDepartment.trim();
    }

    public String getIdTrader() {
        return idTrader;
    }

    public void setIdTrader(String idTrader) {
        this.idTrader = idTrader == null ? null : idTrader.trim();
    }

    public String getIdTrade() {
        return idTrade;
    }

    public void setIdTrade(String idTrade) {
        this.idTrade = idTrade == null ? null : idTrade.trim();
    }

    public String getCdAssetClass() {
        return cdAssetClass;
    }

    public void setCdAssetClass(String cdAssetClass) {
        this.cdAssetClass = cdAssetClass == null ? null : cdAssetClass.trim();
    }

    public String getCdAssetSubClass() {
        return cdAssetSubClass;
    }

    public void setCdAssetSubClass(String cdAssetSubClass) {
        this.cdAssetSubClass = cdAssetSubClass == null ? null : cdAssetSubClass.trim();
    }

    public Date getDtTrade() {
        return dtTrade;
    }

    public void setDtTrade(Date dtTrade) {
        this.dtTrade = dtTrade;
    }

    public Date getDtSettle() {
        return dtSettle;
    }

    public void setDtSettle(Date dtSettle) {
        this.dtSettle = dtSettle;
    }

    public String getCdSettleType() {
        return cdSettleType;
    }

    public void setCdSettleType(String cdSettleType) {
        this.cdSettleType = cdSettleType == null ? null : cdSettleType.trim();
    }

    public String getCdTradeDirection() {
        return cdTradeDirection;
    }

    public void setCdTradeDirection(String cdTradeDirection) {
        this.cdTradeDirection = cdTradeDirection == null ? null : cdTradeDirection.trim();
    }

    public String getCdEvent() {
        return cdEvent;
    }

    public void setCdEvent(String cdEvent) {
        this.cdEvent = cdEvent == null ? null : cdEvent.trim();
    }

    public Double getAmtPriceClean() {
        return amtPriceClean;
    }

    public void setAmtPriceClean(Double amtPriceClean) {
        this.amtPriceClean = amtPriceClean;
    }

    public Double getAmtPriceFull() {
        return amtPriceFull;
    }

    public void setAmtPriceFull(Double amtPriceFull) {
        this.amtPriceFull = amtPriceFull;
    }

    public Double getRateCoupon() {
        return rateCoupon;
    }

    public void setRateCoupon(Double rateCoupon) {
        this.rateCoupon = rateCoupon;
    }

    public Double getAmtNotional() {
        return amtNotional;
    }

    public void setAmtNotional(Double amtNotional) {
        this.amtNotional = amtNotional;
    }

    public Double getAmtAccruedInt() {
        return amtAccruedInt;
    }

    public void setAmtAccruedInt(Double amtAccruedInt) {
        this.amtAccruedInt = amtAccruedInt;
    }

    public Double getAmtSettle() {
        return amtSettle;
    }

    public void setAmtSettle(Double amtSettle) {
        this.amtSettle = amtSettle;
    }

    public Double getRateYtm() {
        return rateYtm;
    }

    public void setRateYtm(Double rateYtm) {
        this.rateYtm = rateYtm;
    }

    public String getNameCounterparty() {
        return nameCounterparty;
    }

    public void setNameCounterparty(String nameCounterparty) {
        this.nameCounterparty = nameCounterparty == null ? null : nameCounterparty.trim();
    }

    public Double getAmtPremiumDiscount() {
        return amtPremiumDiscount;
    }

    public void setAmtPremiumDiscount(Double amtPremiumDiscount) {
        this.amtPremiumDiscount = amtPremiumDiscount;
    }

    public String getIdReviewer() {
        return idReviewer;
    }

    public void setIdReviewer(String idReviewer) {
        this.idReviewer = idReviewer == null ? null : idReviewer.trim();
    }

    public String getIdConfirmer() {
        return idConfirmer;
    }

    public void setIdConfirmer(String idConfirmer) {
        this.idConfirmer = idConfirmer == null ? null : idConfirmer.trim();
    }

    public Double getAmtDistributionPrice() {
        return amtDistributionPrice;
    }

    public void setAmtDistributionPrice(Double amtDistributionPrice) {
        this.amtDistributionPrice = amtDistributionPrice;
    }

    public Double getRatioDistributionFee() {
        return ratioDistributionFee;
    }

    public void setRatioDistributionFee(Double ratioDistributionFee) {
        this.ratioDistributionFee = ratioDistributionFee;
    }

    public Double getAmtUnderwritingPrice() {
        return amtUnderwritingPrice;
    }

    public void setAmtUnderwritingPrice(Double amtUnderwritingPrice) {
        this.amtUnderwritingPrice = amtUnderwritingPrice;
    }

    public Double getAmtFullFee() {
        return amtFullFee;
    }

    public void setAmtFullFee(Double amtFullFee) {
        this.amtFullFee = amtFullFee;
    }

    public Double getAmtFullTax() {
        return amtFullTax;
    }

    public void setAmtFullTax(Double amtFullTax) {
        this.amtFullTax = amtFullTax;
    }

    public Double getAmtFullBrokage() {
        return amtFullBrokage;
    }

    public void setAmtFullBrokage(Double amtFullBrokage) {
        this.amtFullBrokage = amtFullBrokage;
    }

    public String getNameAccount() {
        return nameAccount;
    }

    public void setNameAccount(String nameAccount) {
        this.nameAccount = nameAccount == null ? null : nameAccount.trim();
    }

    public String getTxtNote() {
        return txtNote;
    }

    public void setTxtNote(String txtNote) {
        this.txtNote = txtNote == null ? null : txtNote.trim();
    }

    public String getIdInstrument() {
        return idInstrument;
    }

    public void setIdInstrument(String idInstrument) {
        this.idInstrument = idInstrument == null ? null : idInstrument.trim();
    }
}
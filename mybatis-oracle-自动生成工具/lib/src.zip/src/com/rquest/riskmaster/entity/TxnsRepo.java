package com.rquest.riskmaster.entity;

import java.util.Date;

public class TxnsRepo {
    private Double idTransaction;

    private String idTrade;

    private String idSecurity;

    private String cdTradeDirection;

    private Date dtTrade;

    private String idTrader;

    private Double amtFirstCleanPrice;

    private Double amtMaturityCleanPrice;

    private Double rateYtm;

    private Double amtIntAccrued;

    private Date dtMaturity;

    private String idCounterParty;

    private String nameCounterParty;

    private String nameBond;

    private String idDepartment;

    private Date dtEffective;

    private Double amtPar;

    private Double amtFirst;

    private Double amtMaturity;

    private Double amtFee;

    private Double amtTax;

    private Double amtBrokage;

    private String idPortfolio;

    private String namePortfolio;

    private String idAccount;

    private String nameAccount;

    private String cdSettleType1;

    private String cdSettleType2;

    private String nameDealer;

    private Double nbrRepoDays;

    private String rateRepo;

    private String flagInterbank;

    private String repoType;

    private String cdPurpose;

    private Double nbrVersion;

    private Double amtFee2;

    private Double amtTax2;

    private Double amtBrokage2;

    private String amtFacePart;

    private String idInstrument;

    public Double getIdTransaction() {
        return idTransaction;
    }

    public void setIdTransaction(Double idTransaction) {
        this.idTransaction = idTransaction;
    }

    public String getIdTrade() {
        return idTrade;
    }

    public void setIdTrade(String idTrade) {
        this.idTrade = idTrade == null ? null : idTrade.trim();
    }

    public String getIdSecurity() {
        return idSecurity;
    }

    public void setIdSecurity(String idSecurity) {
        this.idSecurity = idSecurity == null ? null : idSecurity.trim();
    }

    public String getCdTradeDirection() {
        return cdTradeDirection;
    }

    public void setCdTradeDirection(String cdTradeDirection) {
        this.cdTradeDirection = cdTradeDirection == null ? null : cdTradeDirection.trim();
    }

    public Date getDtTrade() {
        return dtTrade;
    }

    public void setDtTrade(Date dtTrade) {
        this.dtTrade = dtTrade;
    }

    public String getIdTrader() {
        return idTrader;
    }

    public void setIdTrader(String idTrader) {
        this.idTrader = idTrader == null ? null : idTrader.trim();
    }

    public Double getAmtFirstCleanPrice() {
        return amtFirstCleanPrice;
    }

    public void setAmtFirstCleanPrice(Double amtFirstCleanPrice) {
        this.amtFirstCleanPrice = amtFirstCleanPrice;
    }

    public Double getAmtMaturityCleanPrice() {
        return amtMaturityCleanPrice;
    }

    public void setAmtMaturityCleanPrice(Double amtMaturityCleanPrice) {
        this.amtMaturityCleanPrice = amtMaturityCleanPrice;
    }

    public Double getRateYtm() {
        return rateYtm;
    }

    public void setRateYtm(Double rateYtm) {
        this.rateYtm = rateYtm;
    }

    public Double getAmtIntAccrued() {
        return amtIntAccrued;
    }

    public void setAmtIntAccrued(Double amtIntAccrued) {
        this.amtIntAccrued = amtIntAccrued;
    }

    public Date getDtMaturity() {
        return dtMaturity;
    }

    public void setDtMaturity(Date dtMaturity) {
        this.dtMaturity = dtMaturity;
    }

    public String getIdCounterParty() {
        return idCounterParty;
    }

    public void setIdCounterParty(String idCounterParty) {
        this.idCounterParty = idCounterParty == null ? null : idCounterParty.trim();
    }

    public String getNameCounterParty() {
        return nameCounterParty;
    }

    public void setNameCounterParty(String nameCounterParty) {
        this.nameCounterParty = nameCounterParty == null ? null : nameCounterParty.trim();
    }

    public String getNameBond() {
        return nameBond;
    }

    public void setNameBond(String nameBond) {
        this.nameBond = nameBond == null ? null : nameBond.trim();
    }

    public String getIdDepartment() {
        return idDepartment;
    }

    public void setIdDepartment(String idDepartment) {
        this.idDepartment = idDepartment == null ? null : idDepartment.trim();
    }

    public Date getDtEffective() {
        return dtEffective;
    }

    public void setDtEffective(Date dtEffective) {
        this.dtEffective = dtEffective;
    }

    public Double getAmtPar() {
        return amtPar;
    }

    public void setAmtPar(Double amtPar) {
        this.amtPar = amtPar;
    }

    public Double getAmtFirst() {
        return amtFirst;
    }

    public void setAmtFirst(Double amtFirst) {
        this.amtFirst = amtFirst;
    }

    public Double getAmtMaturity() {
        return amtMaturity;
    }

    public void setAmtMaturity(Double amtMaturity) {
        this.amtMaturity = amtMaturity;
    }

    public Double getAmtFee() {
        return amtFee;
    }

    public void setAmtFee(Double amtFee) {
        this.amtFee = amtFee;
    }

    public Double getAmtTax() {
        return amtTax;
    }

    public void setAmtTax(Double amtTax) {
        this.amtTax = amtTax;
    }

    public Double getAmtBrokage() {
        return amtBrokage;
    }

    public void setAmtBrokage(Double amtBrokage) {
        this.amtBrokage = amtBrokage;
    }

    public String getIdPortfolio() {
        return idPortfolio;
    }

    public void setIdPortfolio(String idPortfolio) {
        this.idPortfolio = idPortfolio == null ? null : idPortfolio.trim();
    }

    public String getNamePortfolio() {
        return namePortfolio;
    }

    public void setNamePortfolio(String namePortfolio) {
        this.namePortfolio = namePortfolio == null ? null : namePortfolio.trim();
    }

    public String getIdAccount() {
        return idAccount;
    }

    public void setIdAccount(String idAccount) {
        this.idAccount = idAccount == null ? null : idAccount.trim();
    }

    public String getNameAccount() {
        return nameAccount;
    }

    public void setNameAccount(String nameAccount) {
        this.nameAccount = nameAccount == null ? null : nameAccount.trim();
    }

    public String getCdSettleType1() {
        return cdSettleType1;
    }

    public void setCdSettleType1(String cdSettleType1) {
        this.cdSettleType1 = cdSettleType1 == null ? null : cdSettleType1.trim();
    }

    public String getCdSettleType2() {
        return cdSettleType2;
    }

    public void setCdSettleType2(String cdSettleType2) {
        this.cdSettleType2 = cdSettleType2 == null ? null : cdSettleType2.trim();
    }

    public String getNameDealer() {
        return nameDealer;
    }

    public void setNameDealer(String nameDealer) {
        this.nameDealer = nameDealer == null ? null : nameDealer.trim();
    }

    public Double getNbrRepoDays() {
        return nbrRepoDays;
    }

    public void setNbrRepoDays(Double nbrRepoDays) {
        this.nbrRepoDays = nbrRepoDays;
    }

    public String getRateRepo() {
        return rateRepo;
    }

    public void setRateRepo(String rateRepo) {
        this.rateRepo = rateRepo == null ? null : rateRepo.trim();
    }

    public String getFlagInterbank() {
        return flagInterbank;
    }

    public void setFlagInterbank(String flagInterbank) {
        this.flagInterbank = flagInterbank == null ? null : flagInterbank.trim();
    }

    public String getRepoType() {
        return repoType;
    }

    public void setRepoType(String repoType) {
        this.repoType = repoType == null ? null : repoType.trim();
    }

    public String getCdPurpose() {
        return cdPurpose;
    }

    public void setCdPurpose(String cdPurpose) {
        this.cdPurpose = cdPurpose == null ? null : cdPurpose.trim();
    }

    public Double getNbrVersion() {
        return nbrVersion;
    }

    public void setNbrVersion(Double nbrVersion) {
        this.nbrVersion = nbrVersion;
    }

    public Double getAmtFee2() {
        return amtFee2;
    }

    public void setAmtFee2(Double amtFee2) {
        this.amtFee2 = amtFee2;
    }

    public Double getAmtTax2() {
        return amtTax2;
    }

    public void setAmtTax2(Double amtTax2) {
        this.amtTax2 = amtTax2;
    }

    public Double getAmtBrokage2() {
        return amtBrokage2;
    }

    public void setAmtBrokage2(Double amtBrokage2) {
        this.amtBrokage2 = amtBrokage2;
    }

    public String getAmtFacePart() {
        return amtFacePart;
    }

    public void setAmtFacePart(String amtFacePart) {
        this.amtFacePart = amtFacePart == null ? null : amtFacePart.trim();
    }

    public String getIdInstrument() {
        return idInstrument;
    }

    public void setIdInstrument(String idInstrument) {
        this.idInstrument = idInstrument == null ? null : idInstrument.trim();
    }
}
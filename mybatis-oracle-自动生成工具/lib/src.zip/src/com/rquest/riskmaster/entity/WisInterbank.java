package com.rquest.riskmaster.entity;

import java.util.Date;

public class WisInterbank {
    private String nameFund;

    private String cdFundType;

    private String cdAssetType;

    private String idAsset;

    private String cdAssetRating;

    private String idAssetIssuer;

    private Double amtNotional;

    private Double rateRatio;

    private Date dtUpdate;

    private Double nbrVersion;

    private String idFund;

    public String getNameFund() {
        return nameFund;
    }

    public void setNameFund(String nameFund) {
        this.nameFund = nameFund == null ? null : nameFund.trim();
    }

    public String getCdFundType() {
        return cdFundType;
    }

    public void setCdFundType(String cdFundType) {
        this.cdFundType = cdFundType == null ? null : cdFundType.trim();
    }

    public String getCdAssetType() {
        return cdAssetType;
    }

    public void setCdAssetType(String cdAssetType) {
        this.cdAssetType = cdAssetType == null ? null : cdAssetType.trim();
    }

    public String getIdAsset() {
        return idAsset;
    }

    public void setIdAsset(String idAsset) {
        this.idAsset = idAsset == null ? null : idAsset.trim();
    }

    public String getCdAssetRating() {
        return cdAssetRating;
    }

    public void setCdAssetRating(String cdAssetRating) {
        this.cdAssetRating = cdAssetRating == null ? null : cdAssetRating.trim();
    }

    public String getIdAssetIssuer() {
        return idAssetIssuer;
    }

    public void setIdAssetIssuer(String idAssetIssuer) {
        this.idAssetIssuer = idAssetIssuer == null ? null : idAssetIssuer.trim();
    }

    public Double getAmtNotional() {
        return amtNotional;
    }

    public void setAmtNotional(Double amtNotional) {
        this.amtNotional = amtNotional;
    }

    public Double getRateRatio() {
        return rateRatio;
    }

    public void setRateRatio(Double rateRatio) {
        this.rateRatio = rateRatio;
    }

    public Date getDtUpdate() {
        return dtUpdate;
    }

    public void setDtUpdate(Date dtUpdate) {
        this.dtUpdate = dtUpdate;
    }

    public Double getNbrVersion() {
        return nbrVersion;
    }

    public void setNbrVersion(Double nbrVersion) {
        this.nbrVersion = nbrVersion;
    }

    public String getIdFund() {
        return idFund;
    }

    public void setIdFund(String idFund) {
        this.idFund = idFund == null ? null : idFund.trim();
    }
}
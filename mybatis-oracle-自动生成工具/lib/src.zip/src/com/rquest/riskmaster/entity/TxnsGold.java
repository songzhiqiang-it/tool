package com.rquest.riskmaster.entity;

import java.util.Date;

public class TxnsGold {
    private Double idTransaction;

    private String idTrade;

    private Date dtTrade;

    private String idTrader;

    private String idDepartment;

    private String idClient;

    private String nameClient;

    private String cdTradeDirection;

    private String cdEvent;

    private String idSecurity;

    private Double amtContractSize;

    private Double amtVolume;

    private Double amtNotional;

    private Double nbrVersion;

    private String cdPurpose;

    private Double amtMatchPrice;

    public Double getIdTransaction() {
        return idTransaction;
    }

    public void setIdTransaction(Double idTransaction) {
        this.idTransaction = idTransaction;
    }

    public String getIdTrade() {
        return idTrade;
    }

    public void setIdTrade(String idTrade) {
        this.idTrade = idTrade == null ? null : idTrade.trim();
    }

    public Date getDtTrade() {
        return dtTrade;
    }

    public void setDtTrade(Date dtTrade) {
        this.dtTrade = dtTrade;
    }

    public String getIdTrader() {
        return idTrader;
    }

    public void setIdTrader(String idTrader) {
        this.idTrader = idTrader == null ? null : idTrader.trim();
    }

    public String getIdDepartment() {
        return idDepartment;
    }

    public void setIdDepartment(String idDepartment) {
        this.idDepartment = idDepartment == null ? null : idDepartment.trim();
    }

    public String getIdClient() {
        return idClient;
    }

    public void setIdClient(String idClient) {
        this.idClient = idClient == null ? null : idClient.trim();
    }

    public String getNameClient() {
        return nameClient;
    }

    public void setNameClient(String nameClient) {
        this.nameClient = nameClient == null ? null : nameClient.trim();
    }

    public String getCdTradeDirection() {
        return cdTradeDirection;
    }

    public void setCdTradeDirection(String cdTradeDirection) {
        this.cdTradeDirection = cdTradeDirection == null ? null : cdTradeDirection.trim();
    }

    public String getCdEvent() {
        return cdEvent;
    }

    public void setCdEvent(String cdEvent) {
        this.cdEvent = cdEvent == null ? null : cdEvent.trim();
    }

    public String getIdSecurity() {
        return idSecurity;
    }

    public void setIdSecurity(String idSecurity) {
        this.idSecurity = idSecurity == null ? null : idSecurity.trim();
    }

    public Double getAmtContractSize() {
        return amtContractSize;
    }

    public void setAmtContractSize(Double amtContractSize) {
        this.amtContractSize = amtContractSize;
    }

    public Double getAmtVolume() {
        return amtVolume;
    }

    public void setAmtVolume(Double amtVolume) {
        this.amtVolume = amtVolume;
    }

    public Double getAmtNotional() {
        return amtNotional;
    }

    public void setAmtNotional(Double amtNotional) {
        this.amtNotional = amtNotional;
    }

    public Double getNbrVersion() {
        return nbrVersion;
    }

    public void setNbrVersion(Double nbrVersion) {
        this.nbrVersion = nbrVersion;
    }

    public String getCdPurpose() {
        return cdPurpose;
    }

    public void setCdPurpose(String cdPurpose) {
        this.cdPurpose = cdPurpose == null ? null : cdPurpose.trim();
    }

    public Double getAmtMatchPrice() {
        return amtMatchPrice;
    }

    public void setAmtMatchPrice(Double amtMatchPrice) {
        this.amtMatchPrice = amtMatchPrice;
    }
}
package com.rquest.riskmaster.entity;

import java.util.Date;

public class NonStandardAsset {
    private String cdAsset;

    private String nameAsset;

    private String assetType;

    private String bondType;

    private String nameIssuer;

    private String cdCurrency;

    private Date dtIssue;

    private Date dtEffective;

    private Date dtMaturity;

    private Double amtIssueMinUnit;

    private Double amtIssue;

    private String cdDayCount;

    private String rateType;

    private Double fixedRate;

    private String floatingRate;

    private Double floatingRateDirection;

    private Double floatingSpread;

    private String fixingFrequency;

    private String couponFrequency;

    private Date dtFirstCoupon;

    private String paymentFrequency;

    private String compoundFlag;

    private String callFlag;

    private Double callRate;

    private String marketType;

    private Double baseRate;

    private String dtBaseRate;

    private String issueMode;

    private Double floatingCap;

    private Double floatingFloor;

    private String note;

    private String yieldType;

    private String systemFlag;

    private Double amtIssurPrice;

    private Double amtFace;

    private String isNstd;

    private Double assetRating;

    private String productType;

    private Double inputUser;

    private String nstdAssetCode;

    private Double cusNbr;

    private Double nbrVersion;

    public String getCdAsset() {
        return cdAsset;
    }

    public void setCdAsset(String cdAsset) {
        this.cdAsset = cdAsset == null ? null : cdAsset.trim();
    }

    public String getNameAsset() {
        return nameAsset;
    }

    public void setNameAsset(String nameAsset) {
        this.nameAsset = nameAsset == null ? null : nameAsset.trim();
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType == null ? null : assetType.trim();
    }

    public String getBondType() {
        return bondType;
    }

    public void setBondType(String bondType) {
        this.bondType = bondType == null ? null : bondType.trim();
    }

    public String getNameIssuer() {
        return nameIssuer;
    }

    public void setNameIssuer(String nameIssuer) {
        this.nameIssuer = nameIssuer == null ? null : nameIssuer.trim();
    }

    public String getCdCurrency() {
        return cdCurrency;
    }

    public void setCdCurrency(String cdCurrency) {
        this.cdCurrency = cdCurrency == null ? null : cdCurrency.trim();
    }

    public Date getDtIssue() {
        return dtIssue;
    }

    public void setDtIssue(Date dtIssue) {
        this.dtIssue = dtIssue;
    }

    public Date getDtEffective() {
        return dtEffective;
    }

    public void setDtEffective(Date dtEffective) {
        this.dtEffective = dtEffective;
    }

    public Date getDtMaturity() {
        return dtMaturity;
    }

    public void setDtMaturity(Date dtMaturity) {
        this.dtMaturity = dtMaturity;
    }

    public Double getAmtIssueMinUnit() {
        return amtIssueMinUnit;
    }

    public void setAmtIssueMinUnit(Double amtIssueMinUnit) {
        this.amtIssueMinUnit = amtIssueMinUnit;
    }

    public Double getAmtIssue() {
        return amtIssue;
    }

    public void setAmtIssue(Double amtIssue) {
        this.amtIssue = amtIssue;
    }

    public String getCdDayCount() {
        return cdDayCount;
    }

    public void setCdDayCount(String cdDayCount) {
        this.cdDayCount = cdDayCount == null ? null : cdDayCount.trim();
    }

    public String getRateType() {
        return rateType;
    }

    public void setRateType(String rateType) {
        this.rateType = rateType == null ? null : rateType.trim();
    }

    public Double getFixedRate() {
        return fixedRate;
    }

    public void setFixedRate(Double fixedRate) {
        this.fixedRate = fixedRate;
    }

    public String getFloatingRate() {
        return floatingRate;
    }

    public void setFloatingRate(String floatingRate) {
        this.floatingRate = floatingRate == null ? null : floatingRate.trim();
    }

    public Double getFloatingRateDirection() {
        return floatingRateDirection;
    }

    public void setFloatingRateDirection(Double floatingRateDirection) {
        this.floatingRateDirection = floatingRateDirection;
    }

    public Double getFloatingSpread() {
        return floatingSpread;
    }

    public void setFloatingSpread(Double floatingSpread) {
        this.floatingSpread = floatingSpread;
    }

    public String getFixingFrequency() {
        return fixingFrequency;
    }

    public void setFixingFrequency(String fixingFrequency) {
        this.fixingFrequency = fixingFrequency == null ? null : fixingFrequency.trim();
    }

    public String getCouponFrequency() {
        return couponFrequency;
    }

    public void setCouponFrequency(String couponFrequency) {
        this.couponFrequency = couponFrequency == null ? null : couponFrequency.trim();
    }

    public Date getDtFirstCoupon() {
        return dtFirstCoupon;
    }

    public void setDtFirstCoupon(Date dtFirstCoupon) {
        this.dtFirstCoupon = dtFirstCoupon;
    }

    public String getPaymentFrequency() {
        return paymentFrequency;
    }

    public void setPaymentFrequency(String paymentFrequency) {
        this.paymentFrequency = paymentFrequency == null ? null : paymentFrequency.trim();
    }

    public String getCompoundFlag() {
        return compoundFlag;
    }

    public void setCompoundFlag(String compoundFlag) {
        this.compoundFlag = compoundFlag == null ? null : compoundFlag.trim();
    }

    public String getCallFlag() {
        return callFlag;
    }

    public void setCallFlag(String callFlag) {
        this.callFlag = callFlag == null ? null : callFlag.trim();
    }

    public Double getCallRate() {
        return callRate;
    }

    public void setCallRate(Double callRate) {
        this.callRate = callRate;
    }

    public String getMarketType() {
        return marketType;
    }

    public void setMarketType(String marketType) {
        this.marketType = marketType == null ? null : marketType.trim();
    }

    public Double getBaseRate() {
        return baseRate;
    }

    public void setBaseRate(Double baseRate) {
        this.baseRate = baseRate;
    }

    public String getDtBaseRate() {
        return dtBaseRate;
    }

    public void setDtBaseRate(String dtBaseRate) {
        this.dtBaseRate = dtBaseRate == null ? null : dtBaseRate.trim();
    }

    public String getIssueMode() {
        return issueMode;
    }

    public void setIssueMode(String issueMode) {
        this.issueMode = issueMode == null ? null : issueMode.trim();
    }

    public Double getFloatingCap() {
        return floatingCap;
    }

    public void setFloatingCap(Double floatingCap) {
        this.floatingCap = floatingCap;
    }

    public Double getFloatingFloor() {
        return floatingFloor;
    }

    public void setFloatingFloor(Double floatingFloor) {
        this.floatingFloor = floatingFloor;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }

    public String getYieldType() {
        return yieldType;
    }

    public void setYieldType(String yieldType) {
        this.yieldType = yieldType == null ? null : yieldType.trim();
    }

    public String getSystemFlag() {
        return systemFlag;
    }

    public void setSystemFlag(String systemFlag) {
        this.systemFlag = systemFlag == null ? null : systemFlag.trim();
    }

    public Double getAmtIssurPrice() {
        return amtIssurPrice;
    }

    public void setAmtIssurPrice(Double amtIssurPrice) {
        this.amtIssurPrice = amtIssurPrice;
    }

    public Double getAmtFace() {
        return amtFace;
    }

    public void setAmtFace(Double amtFace) {
        this.amtFace = amtFace;
    }

    public String getIsNstd() {
        return isNstd;
    }

    public void setIsNstd(String isNstd) {
        this.isNstd = isNstd == null ? null : isNstd.trim();
    }

    public Double getAssetRating() {
        return assetRating;
    }

    public void setAssetRating(Double assetRating) {
        this.assetRating = assetRating;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType == null ? null : productType.trim();
    }

    public Double getInputUser() {
        return inputUser;
    }

    public void setInputUser(Double inputUser) {
        this.inputUser = inputUser;
    }

    public String getNstdAssetCode() {
        return nstdAssetCode;
    }

    public void setNstdAssetCode(String nstdAssetCode) {
        this.nstdAssetCode = nstdAssetCode == null ? null : nstdAssetCode.trim();
    }

    public Double getCusNbr() {
        return cusNbr;
    }

    public void setCusNbr(Double cusNbr) {
        this.cusNbr = cusNbr;
    }

    public Double getNbrVersion() {
        return nbrVersion;
    }

    public void setNbrVersion(Double nbrVersion) {
        this.nbrVersion = nbrVersion;
    }
}
package com.rquest.riskmaster.entity;

import java.util.Date;

public class TxnsAssetChange {
    private String idBareTrade;

    private String idAlterBalance;

    private String idPartment;

    private String idAccount;

    private String idSptTrade;

    private String cdTradeType;

    private String cdAssetType;

    private String cdBuzType;

    private String cdMajorAsset;

    private String cdMinorAsset;

    private Date dtSettle;

    private Double amtHoldPosition;

    private Double amtHoldFace;

    private Double amtCleanPriceCost;

    private Double interestAdjust;

    private Double fairValueAlter;

    private Double interestCost;

    private Double amtDirtyPriceCost;

    private Double amtPriceEarning;

    private Double amtAmortizeEarning;

    private Double amtInterestEarning;

    private Double fairValueIncome;

    private Double amtTradeExpense;

    private Double rateReal;

    private Double dtEffective;

    private Double dtMaturity;

    private Double amtIncurred;

    private String idBidx;

    public String getIdBareTrade() {
        return idBareTrade;
    }

    public void setIdBareTrade(String idBareTrade) {
        this.idBareTrade = idBareTrade == null ? null : idBareTrade.trim();
    }

    public String getIdAlterBalance() {
        return idAlterBalance;
    }

    public void setIdAlterBalance(String idAlterBalance) {
        this.idAlterBalance = idAlterBalance == null ? null : idAlterBalance.trim();
    }

    public String getIdPartment() {
        return idPartment;
    }

    public void setIdPartment(String idPartment) {
        this.idPartment = idPartment == null ? null : idPartment.trim();
    }

    public String getIdAccount() {
        return idAccount;
    }

    public void setIdAccount(String idAccount) {
        this.idAccount = idAccount == null ? null : idAccount.trim();
    }

    public String getIdSptTrade() {
        return idSptTrade;
    }

    public void setIdSptTrade(String idSptTrade) {
        this.idSptTrade = idSptTrade == null ? null : idSptTrade.trim();
    }

    public String getCdTradeType() {
        return cdTradeType;
    }

    public void setCdTradeType(String cdTradeType) {
        this.cdTradeType = cdTradeType == null ? null : cdTradeType.trim();
    }

    public String getCdAssetType() {
        return cdAssetType;
    }

    public void setCdAssetType(String cdAssetType) {
        this.cdAssetType = cdAssetType == null ? null : cdAssetType.trim();
    }

    public String getCdBuzType() {
        return cdBuzType;
    }

    public void setCdBuzType(String cdBuzType) {
        this.cdBuzType = cdBuzType == null ? null : cdBuzType.trim();
    }

    public String getCdMajorAsset() {
        return cdMajorAsset;
    }

    public void setCdMajorAsset(String cdMajorAsset) {
        this.cdMajorAsset = cdMajorAsset == null ? null : cdMajorAsset.trim();
    }

    public String getCdMinorAsset() {
        return cdMinorAsset;
    }

    public void setCdMinorAsset(String cdMinorAsset) {
        this.cdMinorAsset = cdMinorAsset == null ? null : cdMinorAsset.trim();
    }

    public Date getDtSettle() {
        return dtSettle;
    }

    public void setDtSettle(Date dtSettle) {
        this.dtSettle = dtSettle;
    }

    public Double getAmtHoldPosition() {
        return amtHoldPosition;
    }

    public void setAmtHoldPosition(Double amtHoldPosition) {
        this.amtHoldPosition = amtHoldPosition;
    }

    public Double getAmtHoldFace() {
        return amtHoldFace;
    }

    public void setAmtHoldFace(Double amtHoldFace) {
        this.amtHoldFace = amtHoldFace;
    }

    public Double getAmtCleanPriceCost() {
        return amtCleanPriceCost;
    }

    public void setAmtCleanPriceCost(Double amtCleanPriceCost) {
        this.amtCleanPriceCost = amtCleanPriceCost;
    }

    public Double getInterestAdjust() {
        return interestAdjust;
    }

    public void setInterestAdjust(Double interestAdjust) {
        this.interestAdjust = interestAdjust;
    }

    public Double getFairValueAlter() {
        return fairValueAlter;
    }

    public void setFairValueAlter(Double fairValueAlter) {
        this.fairValueAlter = fairValueAlter;
    }

    public Double getInterestCost() {
        return interestCost;
    }

    public void setInterestCost(Double interestCost) {
        this.interestCost = interestCost;
    }

    public Double getAmtDirtyPriceCost() {
        return amtDirtyPriceCost;
    }

    public void setAmtDirtyPriceCost(Double amtDirtyPriceCost) {
        this.amtDirtyPriceCost = amtDirtyPriceCost;
    }

    public Double getAmtPriceEarning() {
        return amtPriceEarning;
    }

    public void setAmtPriceEarning(Double amtPriceEarning) {
        this.amtPriceEarning = amtPriceEarning;
    }

    public Double getAmtAmortizeEarning() {
        return amtAmortizeEarning;
    }

    public void setAmtAmortizeEarning(Double amtAmortizeEarning) {
        this.amtAmortizeEarning = amtAmortizeEarning;
    }

    public Double getAmtInterestEarning() {
        return amtInterestEarning;
    }

    public void setAmtInterestEarning(Double amtInterestEarning) {
        this.amtInterestEarning = amtInterestEarning;
    }

    public Double getFairValueIncome() {
        return fairValueIncome;
    }

    public void setFairValueIncome(Double fairValueIncome) {
        this.fairValueIncome = fairValueIncome;
    }

    public Double getAmtTradeExpense() {
        return amtTradeExpense;
    }

    public void setAmtTradeExpense(Double amtTradeExpense) {
        this.amtTradeExpense = amtTradeExpense;
    }

    public Double getRateReal() {
        return rateReal;
    }

    public void setRateReal(Double rateReal) {
        this.rateReal = rateReal;
    }

    public Double getDtEffective() {
        return dtEffective;
    }

    public void setDtEffective(Double dtEffective) {
        this.dtEffective = dtEffective;
    }

    public Double getDtMaturity() {
        return dtMaturity;
    }

    public void setDtMaturity(Double dtMaturity) {
        this.dtMaturity = dtMaturity;
    }

    public Double getAmtIncurred() {
        return amtIncurred;
    }

    public void setAmtIncurred(Double amtIncurred) {
        this.amtIncurred = amtIncurred;
    }

    public String getIdBidx() {
        return idBidx;
    }

    public void setIdBidx(String idBidx) {
        this.idBidx = idBidx == null ? null : idBidx.trim();
    }
}
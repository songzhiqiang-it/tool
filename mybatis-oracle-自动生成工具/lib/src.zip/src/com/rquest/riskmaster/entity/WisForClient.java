package com.rquest.riskmaster.entity;

import java.util.Date;

public class WisForClient {
    private String cdProductType;

    private String cdProduct;

    private String nameProduct;

    private Date dtIpoEnd;

    private String cdProductStatus;

    private String flagControl;

    private Date dtEffective;

    private Date dtMaturity;

    private Double amtIssueReal;

    private Double amtTotalShares;

    private String cdBranch;

    private String nameProduct2;

    private String flagControl2;

    private String nameProtocol;

    private String nameManager;

    private Double cdDayCountConvention;

    private Double amtIssuePrice;

    private Double nbrMaturityDays;

    private String cdCurrency;

    private Date dtIncomeEnd;

    private String cdIncomeCurrency;

    public String getCdProductType() {
        return cdProductType;
    }

    public void setCdProductType(String cdProductType) {
        this.cdProductType = cdProductType == null ? null : cdProductType.trim();
    }

    public String getCdProduct() {
        return cdProduct;
    }

    public void setCdProduct(String cdProduct) {
        this.cdProduct = cdProduct == null ? null : cdProduct.trim();
    }

    public String getNameProduct() {
        return nameProduct;
    }

    public void setNameProduct(String nameProduct) {
        this.nameProduct = nameProduct == null ? null : nameProduct.trim();
    }

    public Date getDtIpoEnd() {
        return dtIpoEnd;
    }

    public void setDtIpoEnd(Date dtIpoEnd) {
        this.dtIpoEnd = dtIpoEnd;
    }

    public String getCdProductStatus() {
        return cdProductStatus;
    }

    public void setCdProductStatus(String cdProductStatus) {
        this.cdProductStatus = cdProductStatus == null ? null : cdProductStatus.trim();
    }

    public String getFlagControl() {
        return flagControl;
    }

    public void setFlagControl(String flagControl) {
        this.flagControl = flagControl == null ? null : flagControl.trim();
    }

    public Date getDtEffective() {
        return dtEffective;
    }

    public void setDtEffective(Date dtEffective) {
        this.dtEffective = dtEffective;
    }

    public Date getDtMaturity() {
        return dtMaturity;
    }

    public void setDtMaturity(Date dtMaturity) {
        this.dtMaturity = dtMaturity;
    }

    public Double getAmtIssueReal() {
        return amtIssueReal;
    }

    public void setAmtIssueReal(Double amtIssueReal) {
        this.amtIssueReal = amtIssueReal;
    }

    public Double getAmtTotalShares() {
        return amtTotalShares;
    }

    public void setAmtTotalShares(Double amtTotalShares) {
        this.amtTotalShares = amtTotalShares;
    }

    public String getCdBranch() {
        return cdBranch;
    }

    public void setCdBranch(String cdBranch) {
        this.cdBranch = cdBranch == null ? null : cdBranch.trim();
    }

    public String getNameProduct2() {
        return nameProduct2;
    }

    public void setNameProduct2(String nameProduct2) {
        this.nameProduct2 = nameProduct2 == null ? null : nameProduct2.trim();
    }

    public String getFlagControl2() {
        return flagControl2;
    }

    public void setFlagControl2(String flagControl2) {
        this.flagControl2 = flagControl2 == null ? null : flagControl2.trim();
    }

    public String getNameProtocol() {
        return nameProtocol;
    }

    public void setNameProtocol(String nameProtocol) {
        this.nameProtocol = nameProtocol == null ? null : nameProtocol.trim();
    }

    public String getNameManager() {
        return nameManager;
    }

    public void setNameManager(String nameManager) {
        this.nameManager = nameManager == null ? null : nameManager.trim();
    }

    public Double getCdDayCountConvention() {
        return cdDayCountConvention;
    }

    public void setCdDayCountConvention(Double cdDayCountConvention) {
        this.cdDayCountConvention = cdDayCountConvention;
    }

    public Double getAmtIssuePrice() {
        return amtIssuePrice;
    }

    public void setAmtIssuePrice(Double amtIssuePrice) {
        this.amtIssuePrice = amtIssuePrice;
    }

    public Double getNbrMaturityDays() {
        return nbrMaturityDays;
    }

    public void setNbrMaturityDays(Double nbrMaturityDays) {
        this.nbrMaturityDays = nbrMaturityDays;
    }

    public String getCdCurrency() {
        return cdCurrency;
    }

    public void setCdCurrency(String cdCurrency) {
        this.cdCurrency = cdCurrency == null ? null : cdCurrency.trim();
    }

    public Date getDtIncomeEnd() {
        return dtIncomeEnd;
    }

    public void setDtIncomeEnd(Date dtIncomeEnd) {
        this.dtIncomeEnd = dtIncomeEnd;
    }

    public String getCdIncomeCurrency() {
        return cdIncomeCurrency;
    }

    public void setCdIncomeCurrency(String cdIncomeCurrency) {
        this.cdIncomeCurrency = cdIncomeCurrency == null ? null : cdIncomeCurrency.trim();
    }
}
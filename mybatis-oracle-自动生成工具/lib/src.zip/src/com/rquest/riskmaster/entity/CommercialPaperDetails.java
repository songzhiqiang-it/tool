package com.rquest.riskmaster.entity;

import java.util.Date;

public class CommercialPaperDetails {
    private String idTransaction;

    private String taskType;

    private String buyType;

    private String idContract;

    private String idDraft;

    private String buybizType;

    private String centralBankFlag;

    private String innerFlag;

    private String sameCityFlag;

    private String virtualFlag;

    private String previousHand;

    private String dtPayment;

    private Double postponeDays;

    private Double paymentDays;

    private String dtRpdOpen;

    private String dtRpdDue;

    private Double rpdRate;

    private Double interestRate;

    private Double amtInterest;

    private Double amtInterestByBuyer;

    private Double amtRealPayment;

    private String seqNbr;

    private String contractNbr;

    private String printStatus;

    private Date dtPrint;

    private Double amtRealMoney;

    private Double amtFace;

    private String btchNbr;

    private Double nbrVersion;

    public String getIdTransaction() {
        return idTransaction;
    }

    public void setIdTransaction(String idTransaction) {
        this.idTransaction = idTransaction == null ? null : idTransaction.trim();
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }

    public String getBuyType() {
        return buyType;
    }

    public void setBuyType(String buyType) {
        this.buyType = buyType == null ? null : buyType.trim();
    }

    public String getIdContract() {
        return idContract;
    }

    public void setIdContract(String idContract) {
        this.idContract = idContract == null ? null : idContract.trim();
    }

    public String getIdDraft() {
        return idDraft;
    }

    public void setIdDraft(String idDraft) {
        this.idDraft = idDraft == null ? null : idDraft.trim();
    }

    public String getBuybizType() {
        return buybizType;
    }

    public void setBuybizType(String buybizType) {
        this.buybizType = buybizType == null ? null : buybizType.trim();
    }

    public String getCentralBankFlag() {
        return centralBankFlag;
    }

    public void setCentralBankFlag(String centralBankFlag) {
        this.centralBankFlag = centralBankFlag == null ? null : centralBankFlag.trim();
    }

    public String getInnerFlag() {
        return innerFlag;
    }

    public void setInnerFlag(String innerFlag) {
        this.innerFlag = innerFlag == null ? null : innerFlag.trim();
    }

    public String getSameCityFlag() {
        return sameCityFlag;
    }

    public void setSameCityFlag(String sameCityFlag) {
        this.sameCityFlag = sameCityFlag == null ? null : sameCityFlag.trim();
    }

    public String getVirtualFlag() {
        return virtualFlag;
    }

    public void setVirtualFlag(String virtualFlag) {
        this.virtualFlag = virtualFlag == null ? null : virtualFlag.trim();
    }

    public String getPreviousHand() {
        return previousHand;
    }

    public void setPreviousHand(String previousHand) {
        this.previousHand = previousHand == null ? null : previousHand.trim();
    }

    public String getDtPayment() {
        return dtPayment;
    }

    public void setDtPayment(String dtPayment) {
        this.dtPayment = dtPayment == null ? null : dtPayment.trim();
    }

    public Double getPostponeDays() {
        return postponeDays;
    }

    public void setPostponeDays(Double postponeDays) {
        this.postponeDays = postponeDays;
    }

    public Double getPaymentDays() {
        return paymentDays;
    }

    public void setPaymentDays(Double paymentDays) {
        this.paymentDays = paymentDays;
    }

    public String getDtRpdOpen() {
        return dtRpdOpen;
    }

    public void setDtRpdOpen(String dtRpdOpen) {
        this.dtRpdOpen = dtRpdOpen == null ? null : dtRpdOpen.trim();
    }

    public String getDtRpdDue() {
        return dtRpdDue;
    }

    public void setDtRpdDue(String dtRpdDue) {
        this.dtRpdDue = dtRpdDue == null ? null : dtRpdDue.trim();
    }

    public Double getRpdRate() {
        return rpdRate;
    }

    public void setRpdRate(Double rpdRate) {
        this.rpdRate = rpdRate;
    }

    public Double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    public Double getAmtInterest() {
        return amtInterest;
    }

    public void setAmtInterest(Double amtInterest) {
        this.amtInterest = amtInterest;
    }

    public Double getAmtInterestByBuyer() {
        return amtInterestByBuyer;
    }

    public void setAmtInterestByBuyer(Double amtInterestByBuyer) {
        this.amtInterestByBuyer = amtInterestByBuyer;
    }

    public Double getAmtRealPayment() {
        return amtRealPayment;
    }

    public void setAmtRealPayment(Double amtRealPayment) {
        this.amtRealPayment = amtRealPayment;
    }

    public String getSeqNbr() {
        return seqNbr;
    }

    public void setSeqNbr(String seqNbr) {
        this.seqNbr = seqNbr == null ? null : seqNbr.trim();
    }

    public String getContractNbr() {
        return contractNbr;
    }

    public void setContractNbr(String contractNbr) {
        this.contractNbr = contractNbr == null ? null : contractNbr.trim();
    }

    public String getPrintStatus() {
        return printStatus;
    }

    public void setPrintStatus(String printStatus) {
        this.printStatus = printStatus == null ? null : printStatus.trim();
    }

    public Date getDtPrint() {
        return dtPrint;
    }

    public void setDtPrint(Date dtPrint) {
        this.dtPrint = dtPrint;
    }

    public Double getAmtRealMoney() {
        return amtRealMoney;
    }

    public void setAmtRealMoney(Double amtRealMoney) {
        this.amtRealMoney = amtRealMoney;
    }

    public Double getAmtFace() {
        return amtFace;
    }

    public void setAmtFace(Double amtFace) {
        this.amtFace = amtFace;
    }

    public String getBtchNbr() {
        return btchNbr;
    }

    public void setBtchNbr(String btchNbr) {
        this.btchNbr = btchNbr == null ? null : btchNbr.trim();
    }

    public Double getNbrVersion() {
        return nbrVersion;
    }

    public void setNbrVersion(Double nbrVersion) {
        this.nbrVersion = nbrVersion;
    }
}
package com.rquest.riskmaster.entity;

public class CommercialPapers {
    private String idTransactionOriginal;

    private String draftNbr;

    private String dtRemit;

    private String dtMaturity;

    private Double amtFace;

    private String draftNote;

    private Double nbrVersion;

    public String getIdTransactionOriginal() {
        return idTransactionOriginal;
    }

    public void setIdTransactionOriginal(String idTransactionOriginal) {
        this.idTransactionOriginal = idTransactionOriginal == null ? null : idTransactionOriginal.trim();
    }

    public String getDraftNbr() {
        return draftNbr;
    }

    public void setDraftNbr(String draftNbr) {
        this.draftNbr = draftNbr == null ? null : draftNbr.trim();
    }

    public String getDtRemit() {
        return dtRemit;
    }

    public void setDtRemit(String dtRemit) {
        this.dtRemit = dtRemit == null ? null : dtRemit.trim();
    }

    public String getDtMaturity() {
        return dtMaturity;
    }

    public void setDtMaturity(String dtMaturity) {
        this.dtMaturity = dtMaturity == null ? null : dtMaturity.trim();
    }

    public Double getAmtFace() {
        return amtFace;
    }

    public void setAmtFace(Double amtFace) {
        this.amtFace = amtFace;
    }

    public String getDraftNote() {
        return draftNote;
    }

    public void setDraftNote(String draftNote) {
        this.draftNote = draftNote == null ? null : draftNote.trim();
    }

    public Double getNbrVersion() {
        return nbrVersion;
    }

    public void setNbrVersion(Double nbrVersion) {
        this.nbrVersion = nbrVersion;
    }
}
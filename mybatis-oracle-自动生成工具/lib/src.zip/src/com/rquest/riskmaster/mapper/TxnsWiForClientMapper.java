package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsWiForClient;

public interface TxnsWiForClientMapper {
    int insert(TxnsWiForClient record);

    int insertSelective(TxnsWiForClient record);
}
package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsAssetChange;

public interface TxnsAssetChangeMapper {
    int insert(TxnsAssetChange record);

    int insertSelective(TxnsAssetChange record);
}
package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.CommercialPapers;

public interface CommercialPapersMapper {
    int insert(CommercialPapers record);

    int insertSelective(CommercialPapers record);
}
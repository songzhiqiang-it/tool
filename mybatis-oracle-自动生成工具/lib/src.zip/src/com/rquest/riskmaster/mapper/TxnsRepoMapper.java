package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsRepo;

public interface TxnsRepoMapper {
    int deleteByPrimaryKey(Double idTransaction);

    int insert(TxnsRepo record);

    int insertSelective(TxnsRepo record);

    TxnsRepo selectByPrimaryKey(Double idTransaction);

    int updateByPrimaryKeySelective(TxnsRepo record);

    int updateByPrimaryKey(TxnsRepo record);
}
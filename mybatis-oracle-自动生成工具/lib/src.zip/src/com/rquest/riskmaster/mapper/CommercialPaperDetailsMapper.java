package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.CommercialPaperDetails;

public interface CommercialPaperDetailsMapper {
    int insert(CommercialPaperDetails record);

    int insertSelective(CommercialPaperDetails record);
}
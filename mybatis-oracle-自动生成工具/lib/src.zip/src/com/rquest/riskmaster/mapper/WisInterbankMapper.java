package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.WisInterbank;

public interface WisInterbankMapper {
    int insert(WisInterbank record);

    int insertSelective(WisInterbank record);
}
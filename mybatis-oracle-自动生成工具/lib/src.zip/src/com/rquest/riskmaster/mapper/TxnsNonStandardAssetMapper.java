package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsNonStandardAsset;

public interface TxnsNonStandardAssetMapper {
    int insert(TxnsNonStandardAsset record);

    int insertSelective(TxnsNonStandardAsset record);
}
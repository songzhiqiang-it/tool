package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsBond;

public interface TxnsBondMapper {
    int deleteByPrimaryKey(Double idTransaction);

    int insert(TxnsBond record);

    int insertSelective(TxnsBond record);

    TxnsBond selectByPrimaryKey(Double idTransaction);

    int updateByPrimaryKeySelective(TxnsBond record);

    int updateByPrimaryKey(TxnsBond record);
}
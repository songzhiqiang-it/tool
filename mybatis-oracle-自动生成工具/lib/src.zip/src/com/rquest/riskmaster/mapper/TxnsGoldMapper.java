package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsGold;

public interface TxnsGoldMapper {
    int insert(TxnsGold record);

    int insertSelective(TxnsGold record);
}
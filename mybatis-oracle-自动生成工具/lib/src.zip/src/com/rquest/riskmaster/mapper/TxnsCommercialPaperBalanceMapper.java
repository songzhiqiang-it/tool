package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsCommercialPaperBalance;

public interface TxnsCommercialPaperBalanceMapper {
    int insert(TxnsCommercialPaperBalance record);

    int insertSelective(TxnsCommercialPaperBalance record);
}
package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsInterbankLoan;

public interface TxnsInterbankLoanMapper {
    int deleteByPrimaryKey(Double idTransaction);

    int insert(TxnsInterbankLoan record);

    int insertSelective(TxnsInterbankLoan record);

    TxnsInterbankLoan selectByPrimaryKey(Double idTransaction);

    int updateByPrimaryKeySelective(TxnsInterbankLoan record);

    int updateByPrimaryKey(TxnsInterbankLoan record);
}
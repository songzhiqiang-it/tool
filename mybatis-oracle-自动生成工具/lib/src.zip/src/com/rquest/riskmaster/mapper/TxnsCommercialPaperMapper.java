package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsCommercialPaper;

public interface TxnsCommercialPaperMapper {
    int insert(TxnsCommercialPaper record);

    int insertSelective(TxnsCommercialPaper record);
}
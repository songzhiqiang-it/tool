package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsAccont;

public interface TxnsAccontMapper {
    int insert(TxnsAccont record);

    int insertSelective(TxnsAccont record);
}
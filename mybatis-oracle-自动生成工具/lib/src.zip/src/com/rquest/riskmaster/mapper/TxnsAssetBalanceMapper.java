package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.TxnsAssetBalance;

public interface TxnsAssetBalanceMapper {
    int insert(TxnsAssetBalance record);

    int insertSelective(TxnsAssetBalance record);
}
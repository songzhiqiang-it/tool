package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.WisForClient;

public interface WisForClientMapper {
    int insert(WisForClient record);

    int insertSelective(WisForClient record);
}
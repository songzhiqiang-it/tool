package com.rquest.riskmaster.mapper;

import com.rquest.riskmaster.entity.NonStandardAsset;

public interface NonStandardAssetMapper {
    int insert(NonStandardAsset record);

    int insertSelective(NonStandardAsset record);
}